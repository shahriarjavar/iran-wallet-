package com.example.iranwallet;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.math.BigInteger;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String PREFS = "wallet_prefs";
    private static final String KEY_BALANCE = "display_balance";
    private TextView balanceText;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(12), dp(20), dp(20));
        root.setBackgroundColor(Color.rgb(18,18,18));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("ایران ولت");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        top.addView(title, new LinearLayout.LayoutParams(0, dp(56), 1));

        TextView menu = new TextView(this);
        menu.setText("⋮");
        menu.setTextColor(Color.WHITE);
        menu.setTextSize(30);
        menu.setGravity(Gravity.CENTER);
        menu.setContentDescription("منو");
        menu.setClickable(true);
        menu.setFocusable(true);
        top.addView(menu, new LinearLayout.LayoutParams(dp(48), dp(56)));
        root.addView(top);

        TextView label = new TextView(this);
        label.setText("موجودی");
        label.setTextColor(Color.rgb(158,158,158));
        label.setTextSize(15);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(28);
        root.addView(label, lp);

        balanceText = new TextView(this);
        balanceText.setTextColor(Color.WHITE);
        balanceText.setTextSize(40);
        balanceText.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(4);
        root.addView(balanceText, lp);

        TextView display = new TextView(this);
        display.setText("موجودی نمایشی");
        display.setTextColor(Color.rgb(120,120,120));
        display.setTextSize(12);
        lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(6);
        root.addView(display, lp);

        TextView activityTitle = new TextView(this);
        activityTitle.setText("فعالیت اخیر");
        activityTitle.setTextColor(Color.WHITE);
        activityTitle.setTextSize(17);
        activityTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        activityTitle.setPadding(dp(18), dp(18), dp(18), dp(4));

        TextView empty = new TextView(this);
        empty.setText("تراکنشی ثبت نشده است");
        empty.setTextColor(Color.rgb(158,158,158));
        empty.setTextSize(14);
        empty.setPadding(dp(18), dp(4), dp(18), dp(18));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundColor(Color.rgb(30,30,30));
        card.addView(activityTitle);
        card.addView(empty);
        lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(28);
        root.addView(card, lp);

        setContentView(root);
        updateBalance();
        menu.setOnClickListener(v -> showBalanceDialog());
    }

    private void updateBalance() {
        String raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_BALANCE, "0");
        balanceText.setText(formatToman(raw));
    }

    private String formatToman(String raw) {
        try {
            BigInteger value = new BigInteger(raw);
            DecimalFormatSymbols symbols = DecimalFormatSymbols.getInstance(Locale.US);
            DecimalFormat formatter = new DecimalFormat("#,###", symbols);
            return toPersianDigits(formatter.format(value)) + " تومان";
        } catch (Exception e) {
            return "۰ تومان";
        }
    }

    private String toPersianDigits(String s) {
        return s.replace('0','۰').replace('1','۱').replace('2','۲').replace('3','۳')
                .replace('4','۴').replace('5','۵').replace('6','۶').replace('7','۷')
                .replace('8','۸').replace('9','۹');
    }

    private void showBalanceDialog() {
        final EditText input = new EditText(this);
        input.setHint("مثلاً 25000000");
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setSingleLine(true);
        input.setText(getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_BALANCE, "0"));
        input.setSelection(input.length());
        input.setPadding(dp(20), dp(8), dp(20), dp(8));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("تنظیم موجودی نمایشی")
                .setMessage("این مبلغ فقط داخل برنامه نمایش داده می‌شود و به حساب بانکی یا پرداخت واقعی متصل نیست.")
                .setView(input)
                .setNegativeButton("انصراف", null)
                .setPositiveButton("ذخیره", null)
                .create();

        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String value = input.getText().toString().trim();
                if (value.length() == 0) value = "0";
                try {
                    BigInteger n = new BigInteger(value);
                    if (n.signum() < 0) throw new NumberFormatException();
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_BALANCE, n.toString()).apply();
                    updateBalance();
                    dialog.dismiss();
                    Toast.makeText(this, "موجودی نمایشی ذخیره شد", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    input.setError("فقط عدد مثبت وارد کنید");
                }
            });
            dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
            input.requestFocus();
        });
        dialog.show();
    }
}
