package com.example.iranwallet;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.math.BigInteger;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS = "wallet_prefs";
    private static final String KEY_BALANCE = "display_balance";

    private TextView balanceText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        balanceText = findViewById(R.id.balanceText);
        TextView menuButton = findViewById(R.id.menuButton);

        updateBalance();

        menuButton.setOnClickListener(v -> showBalanceDialog());
    }

    private void updateBalance() {
        String raw = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getString(KEY_BALANCE, "0");
        balanceText.setText(formatToman(raw));
    }

    private String formatToman(String raw) {
        try {
            BigInteger value = new BigInteger(raw);
            DecimalFormatSymbols symbols = DecimalFormatSymbols.getInstance(Locale.US);
            DecimalFormat formatter = new DecimalFormat("#,###", symbols);
            formatter.setGroupingUsed(true);
            return toPersianDigits(formatter.format(value)) + " تومان";
        } catch (Exception e) {
            return "۰ تومان";
        }
    }

    private String toPersianDigits(String s) {
        return s.replace('0','۰').replace('1','۱').replace('2','۲').replace('3','۳')
                .replace('4','۴').replace('5','۵').replace('6','۶').replace('7','۷')
                .replace('8','۸').replace('9','۹');
    }

    private void showBalanceDialog() {
        final EditText input = new EditText(this);
        input.setHint("مثلاً 25000000");
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setSingleLine(true);
        input.setPadding(24, 8, 24, 8);

        String current = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getString(KEY_BALANCE, "0");
        input.setText(current);
        input.setSelection(input.length());

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("تنظیم موجودی نمایشی")
                .setMessage("این مبلغ فقط داخل برنامه نمایش داده می‌شود و به حساب بانکی یا پرداخت واقعی متصل نیست.")
                .setView(input)
                .setNegativeButton("انصراف", null)
                .setPositiveButton("ذخیره", null)
                .create();

        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String value = input.getText().toString().trim();
                if (value.isEmpty()) value = "0";
                try {
                    BigInteger n = new BigInteger(value);
                    if (n.signum() < 0) throw new NumberFormatException();
                    getSharedPreferences(PREFS, MODE_PRIVATE)
                            .edit().putString(KEY_BALANCE, n.toString()).apply();
                    updateBalance();
                    dialog.dismiss();
                    Toast.makeText(this, "موجودی نمایشی ذخیره شد", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    input.setError("لطفاً فقط عدد مثبت وارد کنید");
                }
            });
            input.requestFocus();
            dialog.getWindow().setSoftInputMode(
                    android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        });

        dialog.show();
    }
}
