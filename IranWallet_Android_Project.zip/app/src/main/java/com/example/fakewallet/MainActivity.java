package com.example.fakewallet;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.text.DecimalFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    TextView balance;
    android.content.SharedPreferences prefs;
    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        balance=findViewById(R.id.balance);
        prefs=getSharedPreferences("wallet",0);
        render(prefs.getString("balance","0"));
        findViewById(R.id.settings).setOnClickListener(v -> editBalance());
    }
    String fa(String s){ return s.replace('0','۰').replace('1','۱').replace('2','۲').replace('3','۳').replace('4','۴').replace('5','۵').replace('6','۶').replace('7','۷').replace('8','۸').replace('9','۹').replace(',','٬'); }
    void render(String raw){
        try{
            long n=Long.parseLong(raw);
            balance.setText(fa(String.format(Locale.US,"%,d",n))+" تومان");
        }catch(Exception e){ balance.setText("۰ تومان"); }
    }
    void editBalance(){
        final EditText input=new EditText(this);
        input.setInputType(2); input.setHint("مثلاً 50000000");
        input.setText(prefs.getString("balance","0"));
        AlertDialog d=new AlertDialog.Builder(this).setTitle("تغییر موجودی نمایشی")
          .setMessage("مبلغ دلخواه را به تومان وارد کنید.")
          .setView(input).setNegativeButton("انصراف",null)
          .setPositiveButton("ذخیره",(x,w)->{
              String s=input.getText().toString().replace(",","").trim();
              if(s.matches("\\d{1,18}")){
                 prefs.edit().putString("balance",s).apply(); render(s);
              } else Toast.makeText(this,"مبلغ نامعتبر است",Toast.LENGTH_SHORT).show();
          }).create();
        d.setOnShowListener(x -> input.requestFocus()); d.getWindow();
        d.show();
    }
}